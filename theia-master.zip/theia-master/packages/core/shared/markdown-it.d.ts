import markdownit = require('markdown-it');
export = markdownit;
