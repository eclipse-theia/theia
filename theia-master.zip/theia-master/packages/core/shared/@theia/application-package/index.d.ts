export * from '@theia/application-package';
