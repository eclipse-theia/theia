module.exports = require('@theia/application-package');
