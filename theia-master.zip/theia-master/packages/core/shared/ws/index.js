module.exports = require('ws');
