import React = require('react');
export = React;
