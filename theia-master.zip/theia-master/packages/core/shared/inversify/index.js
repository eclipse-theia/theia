module.exports = require('inversify');
