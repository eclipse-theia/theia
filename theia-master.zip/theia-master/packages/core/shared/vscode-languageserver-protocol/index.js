module.exports = require('vscode-languageserver-protocol');
