module.exports = require('vscode-ws-jsonrpc');
