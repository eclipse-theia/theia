module.exports = require('dompurify');
