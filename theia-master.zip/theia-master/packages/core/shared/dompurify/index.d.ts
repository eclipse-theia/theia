import DOMPurify = require('dompurify');
export = DOMPurify;
