module.exports = require('vscode-uri');
