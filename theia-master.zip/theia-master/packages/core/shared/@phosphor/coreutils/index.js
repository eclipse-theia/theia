module.exports = require('@phosphor/coreutils');
