module.exports = require('@phosphor/algorithm');
