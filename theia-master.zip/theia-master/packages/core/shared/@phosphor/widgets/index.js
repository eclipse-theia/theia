module.exports = require('@phosphor/widgets');
