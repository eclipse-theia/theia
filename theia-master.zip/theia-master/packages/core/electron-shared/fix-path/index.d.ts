import fixPath = require('@theia/electron/shared/fix-path');
export = fixPath;
