module.exports = require('@theia/electron/shared/fix-path');
