import ElectronStore = require('@theia/electron/shared/electron-store');
export = ElectronStore;
