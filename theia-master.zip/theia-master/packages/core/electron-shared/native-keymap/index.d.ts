export * from '@theia/electron/shared/native-keymap';
