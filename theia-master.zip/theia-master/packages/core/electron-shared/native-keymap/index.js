module.exports = require('@theia/electron/shared/native-keymap');
