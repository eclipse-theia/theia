import Electron = require('@theia/electron/shared/electron');
export = Electron;
