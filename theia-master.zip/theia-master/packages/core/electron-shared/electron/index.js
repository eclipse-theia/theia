module.exports = require('@theia/electron/shared/electron');
