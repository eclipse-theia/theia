export * from '@theia/electron/shared/@electron/remote';
